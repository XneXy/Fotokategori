rootProject.name = "PersonalGalleryApp"
include(":app")
