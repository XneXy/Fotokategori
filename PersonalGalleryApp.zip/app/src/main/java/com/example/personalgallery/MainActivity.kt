package com.example.personalgallery

import android.content.ContentResolver
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AppScreen()
        }
    }
}

@Composable
fun AppScreen() {
    val context = LocalContext.current
    var categories by remember { mutableStateOf(loadCategories(context)) }
    var showAddDialog by remember { mutableStateOf(false) }
    var selectedCategory by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Personal Gallery") }) },
        floatingActionButton = {
            Column {
                FloatingActionButton(onClick = { showAddDialog = true }) {
                    Text("Kategori")
                }
            }
        }
    ) { padding ->
        Column(modifier = Modifier.padding(padding)) {
            if (selectedCategory == null) {
                CategoryList(categories) { c -> selectedCategory = c }
            } else {
                CategoryView(category = selectedCategory!!, onBack = {
                    categories = loadCategories(LocalContext.current); selectedCategory = null
                }, refreshCategories = { categories = loadCategories(LocalContext.current) })
            }
        }
    }

    if (showAddDialog) {
        AddCategoryDialog(onDismiss = { showAddDialog = false }, onAdd = { name ->
            createCategory(LocalContext.current, name)
            categories = loadCategories(LocalContext.current)
            showAddDialog = false
        })
    }
}

@Composable
fun CategoryList(categories: List<String>, onOpen: (String) -> Unit) {
    Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
        Text("Kategoriler", style = MaterialTheme.typography.h6)
        Spacer(modifier = Modifier.height(8.dp))
        for (c in categories) {
            Card(modifier = Modifier.fillMaxWidth().padding(4.dp).clickable { onOpen(c) }) {
                Row(modifier = Modifier.padding(12.dp)) {
                    Text(c)
                }
            }
        }
    }
}

@Composable
fun AddCategoryDialog(onDismiss: () -> Unit, onAdd: (String) -> Unit) {
    var text by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Yeni Kategori") },
        text = {
            TextField(value = text, onValueChange = { text = it }, placeholder = { Text("Örn: Messi") })
        },
        confirmButton = {
            TextButton(onClick = { if (text.isNotBlank()) onAdd(text.trim()) }) { Text("Ekle") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("İptal") } }
    )
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun CategoryView(category: String, onBack: () -> Unit, refreshCategories: () -> Unit) {
    val context = LocalContext.current
    var images by remember { mutableStateOf(loadImagesForCategory(context, category)) }

    val launcher = rememberLauncherForActivityResult(contract = ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        LaunchedEffect(uri) {
            if (uri != null) {
                withContext(Dispatchers.IO) {
                    copyUriToCategory(context, uri, category)
                }
                images = loadImagesForCategory(context, category)
            }
        }
    }

    Column(modifier = Modifier.fillMaxSize().padding(12.dp)) {
        Row {
            TextButton(onClick = onBack) { Text("Geri") }
            Spacer(modifier = Modifier.width(8.dp))
            Text("$category", style = MaterialTheme.typography.h6)
            Spacer(modifier = Modifier.weight(1f))
            TextButton(onClick = { launcher.launch(arrayOf("image/*")) }) { Text("Fotoğraf Ekle") }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (images.isEmpty()) {
            Text("Bu kategoride fotoğraf yok.")
        } else {
            LazyVerticalGrid(columns = GridCells.Fixed(3), modifier = Modifier.fillMaxSize()) {
                items(images) { file ->
                    Card(modifier = Modifier.padding(4.dp).fillMaxWidth().clickable {
                        // TODO: full-screen viewer
                    }) {
                        AsyncImage(model = file.absoluteFile, contentDescription = null, modifier = Modifier.size(120.dp))
                    }
                }
            }
        }
    }
}

fun loadCategories(context: android.content.Context): List<String> {
    val base = File(context.filesDir, "categories")
    if (!base.exists()) base.mkdirs()
    return base.listFiles()?.filter { it.isDirectory }?.map { it.name }?.sorted() ?: emptyList()
}

fun createCategory(context: android.content.Context, name: String) {
    val dir = File(context.filesDir, "categories/$name")
    if (!dir.exists()) dir.mkdirs()
}

fun loadImagesForCategory(context: android.content.Context, category: String): List<File> {
    val dir = File(context.filesDir, "categories/$category")
    if (!dir.exists()) return emptyList()
    return dir.listFiles()?.filter { it.isFile }?.sortedBy { it.name } ?: emptyList()
}

suspend fun copyUriToCategory(context: android.content.Context, uri: Uri, category: String) {
    withContext(Dispatchers.IO) {
        val cr: ContentResolver = context.contentResolver
        val time = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val ext = cr.getType(uri)?.let { mime ->
            when {
                mime.contains("jpeg") || mime.contains("jpg") -> "jpg"
                mime.contains("png") -> "png"
                else -> "jpg"
            }
        } ?: "jpg"
        val fileName = "IMG_${time}.$ext"
        val destDir = File(context.filesDir, "categories/$category")
        if (!destDir.exists()) destDir.mkdirs()

        val outFile = File(destDir, fileName)
        cr.openInputStream(uri)?.use { input ->
            outFile.outputStream().use { output ->
                input.copyTo(output)
            }
        }
    }
}
