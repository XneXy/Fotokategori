PersonalGalleryApp - Android (Kotlin, Jetpack Compose)

Bu arşiv Android Studio'da açılmaya hazır bir proje içerir.
NOT: Bu zip bir APK içermez. APK üretmek için:
1) Android Studio'yu açın.
2) File > Open ve bu klasörü seçin.
3) Gradle senkronizasyonuna izin verin.
4) Build > Build Bundle(s) / APK(s) > Build APK(s)
5) Ortaya çıkan APK'yı cihazınıza yükleyin.

İsterseniz ben GitHub Actions konfigürasyonu hazırlayıp bir CI pipeline ile otomatik olarak APK üretecek dosyalar da oluştururum.
